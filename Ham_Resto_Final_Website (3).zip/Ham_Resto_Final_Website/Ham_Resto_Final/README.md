# Ham Resto Website - part two chanches
From the feedback i got from my lecture i was suppose to link my extentenal css file with my web pages <link rel="stylesheet" href="CSS/style.css"> i am required to create a website using Html and also referemcing and i am also suppose to create a javascript and link with either my contact but i linked it with all
## Pages
Home, About, Services, Menu, Order, Gallery, Enquiry and Contact.
## Structure
- CSS/style.css: shared responsive styling
- JS/script.js: navigation, menu filter, gallery lightbox and form handling
- JS/map.js: Leaflet map with address search
- IMAGES/ham-resto-logo.svg: website logo
- IMAGES/Download.mp4: add the real restaurant/lecturer-approved MP4 here
- robots.txt and sitemap.xml: search crawler files
## Run locally
1. Extract this folder and open it in Visual Studio Code.
2. Add approved restaurant photographs and the MP4 file in IMAGES.
3. Open home.html in a browser .
4. Test every page, link, form, filter, gallery control and map.

## Forms
Forms validate in the browser and prepare an email using mailto. They do not store orders or guarantee delivery. A real backend or form service and server-side validation are needed for live online submissions.
# Changes made
- Fixed spelling, repeated text, broken food-delivery list markup and inconsistent page names.
- Added consistent navigation and responsive external CSS.
- Added page titles, meta descriptions, keywords, headings, alt text and internal links.
- Added menu search/filter .
- Added HTML validation, JavaScript form handling and feedback.
- Added Leaflet map address search without inventing the restaurant address.
- Added  sitemap.xml and this README.
- Added new images and video.
- added a menue list 
# Deployment
Push the project to GitHub. Enable GitHub Pages in repository settings, or upload the folder to Netlify. Update sitemap and URLs after publishing and test the live website on mobile and desktop.
