// Ham Resto JavaScript: navigation, menu, gallery and form actions
document.addEventListener("DOMContentLoaded",function(){
 const toggle=document.querySelector(".menu-toggle"),nav=document.querySelector(".main-nav");
 if(toggle&&nav){toggle.addEventListener("click",function(){nav.classList.toggle("open");toggle.setAttribute("aria-expanded",nav.classList.contains("open"));});}
 document.querySelectorAll(".year").forEach(x=>x.textContent=new Date().getFullYear());
 const search=document.getElementById("menu-search"),category=document.getElementById("menu-category"),cards=document.querySelectorAll(".menu-card"),none=document.getElementById("no-meals");
 function filter(){let count=0;cards.forEach(card=>{let ok=card.dataset.name.includes(search.value.toLowerCase())&&(category.value==="all"||card.dataset.category===category.value);card.hidden=!ok;if(ok)count++;});if(none)none.hidden=count>0;}
 if(search&&category){search.addEventListener("input",filter);category.addEventListener("change",filter);}
 const box=document.getElementById("lightbox"),large=document.getElementById("lightbox-image"),close=document.querySelector(".close-lightbox");
 document.querySelectorAll(".gallery-item").forEach(btn=>btn.addEventListener("click",()=>{large.src=btn.dataset.full;large.alt=btn.querySelector("img").alt;box.hidden=false;}));
 function closeBox(){if(box)box.hidden=true;}if(close)close.addEventListener("click",closeBox);if(box)box.addEventListener("click",e=>{if(e.target===box)closeBox();});document.addEventListener("keydown",e=>{if(e.key==="Escape")closeBox();});
 function mailForm(id,feedback,subject,fields){const form=document.getElementById(id);if(!form)return;form.addEventListener("submit",function(e){e.preventDefault();if(!form.reportValidity())return;const data=new FormData(form);let body=fields.map(([label,name])=>label+": "+(data.get(name)||"")).join("\\n");document.getElementById(feedback).textContent="Your email is ready. Please check it and press Send in your email application.";location.href="mailto:info@hamresto.coza?subject="+encodeURIComponent(subject)+"&body="+encodeURIComponent(body);});}
 mailForm("order-form","order-feedback","Ham Resto order request",[["Name","name"],["Phone","phone"],["Email","email"],["Meal","item"],["Quantity","quantity"],["Order type","type"],["Notes","notes"]]);
 mailForm("enquiry-form","enquiry-feedback","Ham Resto enquiry",[["Name","name"],["Email","email"],["Enquiry type","type"],["Question","message"]]);
 mailForm("contact-form","contact-feedback","Message from Ham Resto website",[["Name","name"],["Email","email"],["Message type","type"],["Message","message"]]);
});
