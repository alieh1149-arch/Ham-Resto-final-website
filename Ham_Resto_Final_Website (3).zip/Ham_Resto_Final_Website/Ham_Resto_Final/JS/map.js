// Leaflet map: visitors enter the verified restaurant address.
// No physical address was supplied, so this code does not invent a location.
document.addEventListener("DOMContentLoaded",function(){
 const form=document.getElementById("map-search"),mapBox=document.getElementById("map");
 if(!form||!mapBox||typeof L==="undefined")return;
 const map=L.map("map").setView([-29,24],5);
 L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'}).addTo(map);
 let marker;
 form.addEventListener("submit",async function(e){e.preventDefault();const address=document.getElementById("map-address").value.trim(),feedback=document.getElementById("map-feedback");if(!address){feedback.textContent="Enter the full restaurant address.";return;}feedback.textContent="Searching...";try{const response=await fetch("https://nominatim.openstreetmap.org/search?format=json&limit=1&q="+encodeURIComponent(address));if(!response.ok)throw new Error("Map search unavailable.");const result=await response.json();if(!result.length){feedback.textContent="Address not found. Check the spelling.";return;}const point=[Number(result[0].lat),Number(result[0].lon)];map.setView(point,16);if(marker)map.removeLayer(marker);marker=L.marker(point).addTo(map).bindPopup("Ham Resto address entered").openPopup();feedback.textContent="Location found. Confirm that the pin is correct."; }catch(err){feedback.textContent=err.message;}});
});
